package com.example.wikimedia

import android.app.SearchManager
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import java.net.URL

class MainActivity : AppCompatActivity() {
  //extra
    lateinit var editText: EditText
    lateinit var btnSearch:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

      //extra
        editText=findViewById(R.id.text3)
        btnSearch=findViewById(R.id.btn)

        btnSearch.setOnClickListener {
            val intent=Intent(Intent.ACTION_WEB_SEARCH)
            val term=editText.text.toString()
//        startActivity(Intent(this@MainActivity,HomeActivity::class.java))
            intent.putExtra(SearchManager.QUERY,term)
            startActivity(intent)
        }


        //on click listner
//        val button=findViewById<Button>(R.id.btn)
//        button.setOnClickListener {
//            startActivity(Intent(this@MainActivity,HomeActivity::class.java))
//        }

//        //onclick search Button
//
//
//        //Our Website
        val myWebView:WebView = findViewById(R.id.myURL)
        myWebView.webViewClient=object:WebViewClient()
        {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                url: String?
            ): Boolean {
                view?.loadUrl(url.toString())
                return true
//                return super.shouldOverrideUrlLoading(view, request)
            }
        }
        myWebView.loadUrl("https://www.wikipedia.org/")
        myWebView.settings.javaScriptEnabled=true
        myWebView.settings.allowContentAccess=true
        myWebView.settings.domStorageEnabled=true
        myWebView.settings.useWideViewPort=true
        myWebView.settings.setAppCacheEnabled(true)
    }

}

